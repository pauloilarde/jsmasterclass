Symbol("a") == Symbol("a");
Symbol("b") == Symbol("b");
Symbol("c") == Symbol("c");
